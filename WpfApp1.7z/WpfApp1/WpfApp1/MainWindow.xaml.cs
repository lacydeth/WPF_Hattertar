﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSzamol_Click(object sender, RoutedEventArgs e)
        {
            double mennyiseg = 1;
            double sebesseg = 1;

            if (cbMennyiseg.Text == "TB")
            {
                 mennyiseg = Convert.ToInt64(tbMennyiseg.Text) / 1000000;
            }
            else if (cbMennyiseg.Text == "GB")
            {
                mennyiseg = Convert.ToInt64(tbMennyiseg.Text) / 1000;
            }
            else if (cbSebesseg.Text == "KB")
            {
                mennyiseg = Convert.ToDouble(tbMennyiseg.Text) * 1000;
            }
            else if (cbSebesseg.Text == "MB")
            {
                mennyiseg = Convert.ToDouble(tbMennyiseg.Text);
            }
            
            if (cbSebesseg.Text == "GBps")
            {
                sebesseg = Convert.ToInt64(sldSebesseg.Value) / 1000;
            }
            else if (cbSebesseg.Text == "KBps")
            {
                sebesseg = Convert.ToInt64(sldSebesseg.Value) * 1000;
            }
            else if (cbSebesseg.Text == "MBps")
            {
                sebesseg = Convert.ToDouble(sldSebesseg.Value);
            }
            
            //lblEredmeny.Content = sebesseg;
            lblEredmeny.Content = mennyiseg % sebesseg;
            
        }

        private void sldSebesseg_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double slderedmeny = Convert.ToDouble(sldSebesseg.Value);
            lblSebesseg.Content = slderedmeny;
        }
    }
}
